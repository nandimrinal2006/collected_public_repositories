---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Bug Description**
A clear and concise description of what the bug is.

**My Action Config**
```yaml
on: push
name: Publish Website
jobs:
  web-deploy:
    name: 🚀 Deploy website every commit
    # !!!!!!! TODO Fill Out !!!!!!!
```

**My Action Log**
```
   # Paste Log here
   # you may want enable verbose logging with   log-level: verbose
```
